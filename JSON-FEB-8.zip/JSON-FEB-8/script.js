import data from "./demo.json" assert { type: "json" };

const kp = data;
// const search = document.getElementById("SearchInput");
// search.addEventListener("keyup",searchfunc);
// // console.log(kp);
// console.log(objdata);

for (let i = 0; i < kp.length; i++) {
  // console.log(kp.length);
  let k = kp[i];

  function calcage(dob) {
    var dif = Date.now() - dob.getTime();
    var adt = new Date(dif);
    // console.log("ddd",age_dt.getUTCFullYear());
    return Math.abs(adt.getUTCFullYear() - 1970);
  }

  let displayAge = calcage(new Date(k.profile.dob));

  var utcDate = k.createdAt;
  // console.log(utcDate)
  var datec = new Date();
  var date1 = datec.toLocaleString();

  // ************for updated at**************

  var utcDate1 = k.updatedAt;
  var dateu = new Date(utcDate1);
  var date = dateu.toLocaleString();

  // ***********************
  var la = k.profile.location.lat + " , " + k.profile.location.long;

  // console.table(la);

  selected.innerHTML += `<tr>
    <td>${k.email}</td>
    <td>${k.profile.name}</td>
    <td>${la}</td>
    <td>${k.profile.company}</td>
    <td>${k.profile.dob}</td>
    <td>${displayAge}</td>
    <td>${date1}</td>
    <td>${date}</td>
   
    
    </tr>`;
}

document.getElementById("SearchInput").addEventListener("keyup", () => {
  let searchinput = document.getElementById("SearchInput").value;
  let filter = searchinput.toUpperCase();
  selected.innerHTML = "";
  for (let j = 0; j < kp.length; j++) {
    let k = kp[j];
    let filteredName = k.profile.name.toUpperCase();
    if (filteredName.indexOf(filter) > -1) {
      function calcage(dob) {
        var dif = Date.now() - dob.getTime();
        var adt = new Date(dif);
        // console.log("ddd",age_dt.getUTCFullYear());
        return Math.abs(adt.getUTCFullYear() - 1970);
      }

      let displayAge = calcage(new Date(k.profile.dob));

      var utcDate = k.createdAt;
      // console.log(utcDate)
      var datec = new Date();
      var date1 = datec.toLocaleString();

      // ************for updated at**************

      var utcDate1 = k.updatedAt;
      var dateu = new Date(utcDate1);
      var date = dateu.toLocaleString();

      // ***********************
      var la = k.profile.location.lat + " , " + k.profile.location.long;

      selected.innerHTML += `<tr>
    <td>${k.email}</td>
    <td>${k.profile.name}</td>
    <td>${la}</td>
    <td>${k.profile.company}</td>
    <td>${k.profile.dob}</td>
    <td>${displayAge}</td>
    <td>${date1}</td>
    <td>${date}</td>
   
    
    </tr>`;
    }
  }
  //   console.log(filter);
});

const checkbox = document.getElementById("admin");
// selected.innerHTML = "";
let ad = checkbox.addEventListener("change", (event) => {
  selected.innerHTML = ""
  if (event.currentTarget.checked) {
    for (let i=0;i<kp.length;i++){
        // console.log(kp[k].roles);
        let rl= kp[i].roles;
        // console.log(rl);
        // for(let o=0;o<rl.length;o++){
        //     console.log(o<rl.length );
           if(rl.includes("admin")){
            // console.log("kkk");
             let k = kp[i];
             
            function calcage(dob) {
              var dif = Date.now() - dob.getTime();
              var adt = new Date(dif);
              // console.log("ddd",age_dt.getUTCFullYear());
              return Math.abs(adt.getUTCFullYear() - 1970);
            }
          
            let displayAge = calcage(new Date(k.profile.dob));
          
            var utcDate = k.createdAt;
            // console.log(utcDate)
            var datec = new Date();
            var date1 = datec.toLocaleString();
          
            // ************for updated at**************
          
            var utcDate1 = k.updatedAt;
            var dateu = new Date(utcDate1);
            var date = dateu.toLocaleString();
          
            // ***********************
            var la = k.profile.location.lat + " , " + k.profile.location.long;
          
            // console.table(la);
          
            selected.innerHTML += `<tr>
              <td>${k.email}</td>
              <td>${k.profile.name}</td>
              <td>${la}</td>
              <td>${k.profile.company}</td>
              <td>${k.profile.dob}</td>
              <td>${displayAge}</td>
              <td>${date1}</td>
              <td>${date}</td>
             
              
              </tr>`;
            
            console.log(k.email)
           }
        // }
    }
    // console.log("knknlkn", kp);
  } else {
    alert("not checked");
  }
});
