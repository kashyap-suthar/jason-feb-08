import data from "./demo.json" assert { type: "json" };

// console.log(data);
// ------------ Declarations --------------
const kp = data;
let selected = document.getElementById("selected");
// let roleId = document.getElementById("roleValue");

window.onload = () => {
  for (let i = 0; i < kp.length; i++) {
    let k = kp[i];
    let displayAge = calcAge(new Date(k.profile.dob));

    let createdAt = k.createdAt;

    let dateC = new Date(createdAt);
    let date1 = dateC.toLocaleString();

    let updateAt = k.updatedAt;

    let dateU = new Date(updateAt);
    let date = dateU.toLocaleString();

    let location = k.profile.location.lat + " , " + k.profile.location.long;

    selected.innerHTML += `<tr>
    <td>${k.email}</td>
    <td>${k.profile.name}</td>
    <td>${location}</td>
    <td>${k.profile.company}</td>
    <td>${k.profile.dob}</td>
    <td>${displayAge}</td>
    <td>${date1}</td>
    <td>${date}</td>
    </tr>`;
  }
};
//   document.getElementById.innerHTML = selected;

document.getElementById("SearchInput").addEventListener("keyup", () => {
  let searchinput = document.getElementById("SearchInput").value;
  let filter = searchinput.toUpperCase();
  //   console.log(hey)
  selected.innerHTML = "";
  for (let j = 0; j < kp.length; j++) {
    let k = kp[j];
    let filteredName = k.profile.name.toUpperCase();
    if (filteredName.indexOf(filter) > -1) {
      printTable(j);
    }
  }
});

document.getElementById("SearchInputC").addEventListener("keyup", () => {
  let searchinput = document.getElementById("SearchInputC").value;
  let filter = searchinput.toUpperCase();
  //   console.log(hey)
  selected.innerHTML = "";
  for (let j = 0; j < kp.length; j++) {
    let k = kp[j];
    let filteredName = k.profile.company.toUpperCase();
    if (filteredName.indexOf(filter) > -1) {
      printTable(j);
    }
  }
});

roleValue.addEventListener("click", () => {
  const checkedArray = document.querySelectorAll(
    "input[type='checkbox']:checked"
  );
  console.log(checkedArray);
  let arr = [];
  for (let j = 0; j < checkedArray.length; j++) {
    arr.push(checkedArray[j].value);
  }

  // console.log('array', arr)
  if (checkedArray.length != 0) {
    selected.innerHTML = "";
    // console.log('heyy')
    for (let i = 0; i < kp.length; i++) {
      let k = kp[i];
      let role = k.roles;
      if (arr.every((element) => role.includes(element))) {
        let displayAge = calcAge(new Date(k.profile.dob));

        let createdAt = k.createdAt;

        let dateC = new Date(createdAt);
        let date1 = dateC.toLocaleString();

        let updateAt = k.updatedAt;

        let dateU = new Date(updateAt);
        let date = dateU.toLocaleString();

        let location = k.profile.location.lat + " , " + k.profile.location.long;

        selected.innerHTML += `<tr>
        <td>${k.email}</td>
        <td>${k.profile.name}</td>
        <td>${location}</td>
        <td>${k.profile.company}</td>
        <td>${k.profile.dob}</td>
        <td>${displayAge}</td>
        <td>${date1}</td>
        <td>${date}</td>
        </tr>`;

        // console.log("", kp[i].profile.name);
      }
    }
  } else {
    selected.innerHTML = "";
    for (let i = 0; i < kp.length; i++) {
      printTable(i);
    }
  }
});

// -------------- Functions -------------
function calcAge(age) {
  var diff = Date.now() - age.getTime();
  var adt = new Date(diff);
  return Math.abs(adt.getUTCFullYear() - 1970);
}

function printTable(i) {
  let k = kp[i];
  let displayAge = calcAge(new Date(k.profile.dob));

  let createdAt = k.createdAt;

  let dateC = new Date(createdAt);
  let date1 = dateC.toLocaleString();

  let updateAt = k.updatedAt;

  let dateU = new Date(updateAt);
  let date = dateU.toLocaleString();

  let location = k.profile.location.lat + " , " + k.profile.location.long;

  selected.innerHTML += `<tr>
  <td>${k.email}</td>
    <td>${k.profile.name}</td>
    <td>${location}</td>
    <td>${k.profile.company}</td>
    <td>${k.profile.dob}</td>
    <td>${displayAge}</td>
    <td>${date1}</td>
    <td>${date}</td>
    </tr>`;
}
