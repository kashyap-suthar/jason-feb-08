$(document).ready(function() {
    $("#search-input").on("input", function() {
      filterTable($(this).val());
    });
  
    function filterTable(value) {
      $("#selected").empty();
  
      for (let i = 0; i < kp.length; i++) {
        let k = kp[i];
  
        function calcage(dob) {
          var dif = Date.now() - dob.getTime();
          var adt = new Date(dif);
          return Math.abs(adt.getUTCFullYear() - 1970);
        }
  
        let displayAge = calcage(new Date(k.profile.dob));
  
        var utcDate = k.createdAt;
        var datec = new Date();
        var date1 = datec.toLocaleString();
  
        var utcDate1 = k.updatedAt;
        var dateu = new Date(utcDate1);
        var date = dateu.toLocaleString();
  
        var la = k.profile.location.lat + " , " + k.profile.location.long;
  
        if (k.profile.name.toLowerCase().indexOf(value.toLowerCase()) > -1) {
          $("#selected").append(
            "<tr>" +
              "<td>" +
                k.email +
              "</td>" +
              "<td>" +
                k.profile.name +
              "</td>" +
              "<td>" +
                la +
              "</td>" +
              "<td>" +
                k.profile.company +
              "</td>" +
              "<td>" +
                k.profile.dob +
              "</td>" +
              "<td>" +
                displayAge +
              "</td>" +
              "<td>" +
                date1 +
              "</td>" +
              "<td>" +
                date +
              "</td>" +
            "</tr>"
          );
        }
      }
    }
  });
  function searchfunc(){
    
    selected.innerHTML ='';

for(let i=0; i<=kp.length;i++){

    // console.log(kp.length);
    let k = kp[i];
    
    function calcage(dob) { 
            var dif = Date.now() - dob.getTime();
            var adt = new Date(dif); 
            // console.log("ddd",age_dt.getUTCFullYear());
            return Math.abs(adt.getUTCFullYear() - 1970);
        }
        
        let displayAge=calcage(new Date(k.profile.dob));
        
        var utcDate = k.createdAt;
        // console.log(utcDate)
        var datec = new Date();
        var date1 = datec.toLocaleString();
     
        // ************for updated at**************
        
        var utcDate1 = k.updatedAt;
        var dateu = new Date(utcDate1);
        var date = dateu.toLocaleString();
        

        // ***********************
        var la =k.profile.location.lat +" , "+ k.profile.location.long;
        
        // console.table(la);
        
        
    
    
    selected.innerHTML += 
    `<tr>
    <td>${k.email}</td>
    <td>${k.profile.name}</td>
    <td>${la}</td>
    <td>${k.profile.company}</td>
    <td>${k.profile.dob}</td>
    <td>${displayAge}</td>
    <td>${date1}</td>
    <td>${date}</td>
   
    
    </tr>`;
    
   
}

}  